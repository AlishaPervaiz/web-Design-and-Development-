<!-- Footer -->
<footer class="bg-white">
    <div class="w-full px-4 sm:px-6 lg:px-16 xl:px-20 py-12 lg:py-[100px]">
        <div class="grid grid-cols-1 md:grid-cols-4 gap-10 md:gap-30 justify-center">
            <!-- Brand & Contact Info -->
            <div class="md:col-span-1">
                <div class="flex-shrink-0 flex items-center gap-4 md:gap-2 lg:gap-2 mb-5 md:mb-24">
                    <img src="<?php echo ASSETS_PATH; ?>Group.webp" alt="Cliffside Icon" class="h-[48px] w-auto object-contain" loading="lazy" />
                    <a href="index.php" class="block">
                        <img src="<?php echo ASSETS_PATH; ?>CliffsideLogo.webp" alt="Cliffside Logo" class="h-[25px] w-auto object-contain" loading="lazy" />
                    </a>
                </div>

                <div class="space-y-5">
                    <!-- Location -->
                    <div class="flex items-center gap-3">
                        <div class="w-10 h-10 bg-[#02B578]/10 rounded-lg flex items-center justify-center">
                            <svg class="w-5 h-5 text-[#02B578]" fill="currentColor" viewBox="0 0 24 24">
                                <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z" />
                            </svg>
                        </div>
                        <div>
                            <p class="text-sm font-medium text-gray-900"><?php echo $contact_info['location']; ?></p>
                            <p class="text-xs text-gray-500"><?php echo $contact_info['address']; ?></p>
                        </div>
                    </div>
                    
                    <!-- Phone -->
                    <div class="flex items-center gap-3">
                        <div class="w-10 h-10 bg-[#02B578]/10 rounded-lg flex items-center justify-center">
                            <svg class="w-5 h-5 text-[#02B578]" fill="currentColor" viewBox="0 0 24 24">
                                <path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z" />
                            </svg>
                        </div>
                        <div>
                            <p class="text-sm font-medium text-gray-900"><?php echo $contact_info['phone']; ?></p>
                            <p class="text-xs text-gray-500">Call us directly</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Footer Menus -->
            <div class="md:col-span-2 grid grid-cols-1 sm:grid-cols-3 gap-8 lg:gap-12">
                <?php foreach ($footer_menus as $menu_key => $menu): ?>
                    <div class="lg:col-span-1">
                        <h4 class="text-lg font-bold text-gray-900 mb-4 font-[var(--main-font)]">
                            <?php if ($menu_key === 'contact_us'): ?>
                                <a href="book_a_free_consultation.php" class="hover:text-[#02B578] transition-colors"><?php echo $menu['title']; ?></a>
                            <?php else: ?>
                                <?php echo $menu['title']; ?>
                            <?php endif; ?>
                        </h4>
                        <ul class="space-y-4">
                            <?php foreach ($menu['items'] as $item_name => $item_url): ?>
                                <li>
                                    <a href="<?php echo $item_url; ?>" class="text-gray-600 hover:text-[#02B578] text-sm transition-colors duration-200 flex items-center">
                                        <span class="w-1 h-1 bg-[#02B578] rounded-full mr-3 opacity-0 group-hover:opacity-100 transition-opacity"></span>
                                        <?php echo $item_name; ?>
                                    </a>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endforeach; ?>
            </div>

            <!-- Newsletter Subscription -->
            <div class="md:col-span-1">
                <h4 class="text-lg font-bold text-gray-900 mb-4 font-[var(--main-font)]">Stay Updated</h4>
                <p class="text-gray-600 text-sm mb-6">Get the latest cybersecurity insights and updates delivered to your inbox.</p>

                <div class="space-y-4">
                    <form method="POST" action="#" class="space-y-4">
                        <div class="relative">
                            <input type="email" name="email" placeholder="Enter your email address" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#02B578] focus:border-transparent transition-colors" required />
                            <div class="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                                <svg class="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                                </svg>
                            </div>
                        </div>
                        <button type="submit" class="w-full bg-[#02B578] hover:bg-[#02B578]/90 text-white font-semibold py-3 px-4 rounded-lg transition-all duration-300 transform hover:-translate-y-1 shadow-lg hover:shadow-xl">
                            Subscribe Now
                        </button>
                    </form>
                    <p class="text-gray-500 text-xs text-center">By subscribing, you agree to our Privacy Policy and consent to receive updates.</p>
                </div>
            </div>
        </div>

        <!-- Bottom Section -->
        <div class="mt-16 pt-8 border-t border-gray-200">
            <div class="flex flex-col md:flex-row justify-between items-center gap-4">
                <p class="text-gray-500 text-sm text-center md:text-left">
                    &copy; <?php echo date('Y'); ?> CliffSide Cybersecurity. All rights reserved.
                </p>
                <div class="flex items-center gap-6">
                    <a href="#" class="text-gray-400 hover:text-[#02B578] transition-colors">
                        <span class="sr-only">Privacy Policy</span>
                        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm0 10.99h7c-.53 4.12-3.28 7.79-7 8.94V12H5V6.3l7-3.11v8.8z"/>
                        </svg>
                    </a>
                    <a href="#" class="text-gray-400 hover:text-[#02B578] transition-colors">
                        <span class="sr-only">Terms of Service</span>
                        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z"/>
                        </svg>
                    </a>
                </div>
            </div>
        </div>
    </div>
</footer>

<!-- Scripts -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" defer></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js" defer></script>
<script src="script.js" defer></script>
</body>
</html>